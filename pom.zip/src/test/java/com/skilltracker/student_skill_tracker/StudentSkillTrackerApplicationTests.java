package com.skilltracker.student_skill_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentSkillTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
